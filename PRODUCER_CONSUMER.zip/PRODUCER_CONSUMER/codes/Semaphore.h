#pragma once

#include <mutex>
#include <condition_variable>
#include <chrono>

class Semaphore {
public:
	Semaphore(unsigned int count);
	template<typename R, typename P>
	bool wait(const std::chrono::duration<R, P>& crRelTime);
	void signal();
	void wait();
	void wait(bool print, bool& isRunning);

private:
	unsigned int m_count;
	std::mutex m_mutex;
	std::condition_variable m_condition;
};
