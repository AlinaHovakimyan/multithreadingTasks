#pragma once

typedef int data_type;
namespace RunData {
	const int buffer_capasity = 5;
	extern int Consumer_Count;            //Count of consumer threads to be runned to end the work 
}
