#include "Definitions.h"
#include "Semaphore.h"
#include "OutWriter.h"

#include <string>
#include <time.h>
#include <queue>
#include <thread>

int RunData::Consumer_Count = 200;
std::queue<data_type> buffer;
Semaphore mutex(1);
Semaphore items(0);
Semaphore spaces(RunData::buffer_capasity);

void Produce() {
	data_type buffer_data = 0;
	int used_size = 0;
	bool producerIsRunning = true;
	OutWriter::getWriter()->setProducerId(std::this_thread::get_id());
	srand(time(NULL));
	while (RunData::Consumer_Count) {
		buffer_data = rand() % 100;
		std::this_thread::sleep_for(std::chrono::nanoseconds(rand() % 5000));
		spaces.wait(true, producerIsRunning);
		if (!producerIsRunning) {
			OutWriter::getWriter()->writeThreadState(OutWriter::RUNNING);
			producerIsRunning = true;
		}

		mutex.wait();
		buffer.push(buffer_data);
		used_size = buffer.size();
		mutex.signal();

		items.signal();
		OutWriter::getWriter()->write(OutWriter::PRODUCER, buffer_data, used_size);
	}
}

void Consume() {
	int data = 0;
	int used_size = 0;
	bool consumerIsRunning = true;
	OutWriter::getWriter()->setConsumerId(std::this_thread::get_id());
	srand(time(NULL));
	while (RunData::Consumer_Count) {
		--RunData::Consumer_Count;
		std::this_thread::sleep_for(std::chrono::nanoseconds(rand() % 5000));
		items.wait(true, consumerIsRunning);
		if (!consumerIsRunning) {
			OutWriter::getWriter()->writeThreadState(OutWriter::RUNNING);
			consumerIsRunning = true;
		}
		
		mutex.wait();
		data = buffer.front();
		buffer.pop();
		used_size = buffer.size();
		mutex.signal();

		spaces.signal();
		OutWriter::getWriter()->write(OutWriter::COSTUMER, data, used_size);
	}
}

int main()
{
	OutWriter::getWriter()->writeBufferState();              // initial state
	std::thread produsers_t(Produce);
	std::thread costumers_t(Consume);

	produsers_t.join();
	costumers_t.join();

	return 0;
}