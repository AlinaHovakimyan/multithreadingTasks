#pragma once

#include <mutex>
#include <queue>
#include <fstream>

class OutWriter {
public:
	enum Changer {
		PRODUCER,
		COSTUMER
	};
	enum State {
		WAITING,
		RUNNING
	};
public:
	static OutWriter* getWriter();
	void writeThreadState(State state);
	void writeBufferState(const int size = 0);
	void write(Changer changer, const int data, const int size);
	void setProducerId(const std::thread::id id);
	void setConsumerId(const std::thread::id id);
private:
	OutWriter();
	~OutWriter();
private:
	static OutWriter* m_outWriter;
	static std::mutex m_mutex;
	std::ofstream m_outputFile;
	std::thread::id m_producerId;
	std::thread::id m_consumerId;
};
