#pragma once

#include <string>

class ExceptionError {
public:
	ExceptionError(std::string message) {
		m_message = message;
	}
	const std::string& getError() const { return m_message; };
private:
	std::string m_message;
};