#include "OutWriter.h"

#include "ExceptionError.h"
#include "Definitions.h"

OutWriter::OutWriter()
{
	 m_outputFile.open("output.txt");
}

OutWriter::~OutWriter()
{
	m_outputFile.close();
}

OutWriter* OutWriter::getWriter()
{
	if (!m_outWriter) {
		m_outWriter = new OutWriter();
	}
	return m_outWriter;
}

void OutWriter::writeThreadState(State state)
{
	std::unique_lock<std::mutex> lock(m_mutex);
	std::string thread = (std::this_thread::get_id() == m_producerId) ? "Producer" : "Consumer";
	switch (state) {
	case RUNNING:
		m_outputFile << thread << " thread's state changed to RUNNING" << std::endl;
		break;
	case WAITING:
		m_outputFile << thread << " thread's state changed to WAITING" << std::endl;
		break;
	default:
		throw ExceptionError("unknown state");
	}
}

void OutWriter::writeBufferState(const int size)
{
	m_outputFile << "Buffer Capacity: " << RunData::buffer_capasity;
	m_outputFile << " Used: " << size;
	m_outputFile << " Free: " << RunData::buffer_capasity - size;
	m_outputFile << std::endl;
}

void OutWriter::write(Changer changer, const int data, const int size)
{
	std::unique_lock<std::mutex> lock(m_mutex);
	switch (changer) {          
	case PRODUCER:				
		m_outputFile << "PRODUCER: Created Data: " << data << " ";
		break;
	case COSTUMER:
		m_outputFile << "COSTUMER: Getted Data: " << data << " ";
		break;
	default:
		throw ExceptionError("unknown buffer changer");
	}
	writeBufferState(size);
}
void OutWriter::setProducerId(const std::thread::id id)
{
	m_producerId = id;
}

void OutWriter::setConsumerId(const std::thread::id id)
{
	m_consumerId = id;
}

std::mutex OutWriter::m_mutex;
OutWriter* OutWriter::m_outWriter;
