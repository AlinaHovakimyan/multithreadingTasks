#include "Philosopher.h"
#include "Definitions.h"
#include "OutWriter.h"

std::vector<Semaphore> forks(RunData::philosophers_count, Semaphore(1));

void Philosopher::think(int index) {
	OutWriter::getWriter()->writePhilosopherState(OutWriter::PhilosopherState::THINK, index);
	std::this_thread::sleep_for(std::chrono::milliseconds(Philosopher::think_duration));
}

void Philosopher::eat(int index) {
	OutWriter::getWriter()->writePhilosopherState(OutWriter::PhilosopherState::EAT, index);
	std::this_thread::sleep_for(std::chrono::milliseconds(Philosopher::eat_duration));
}

void Philosopher::get_forks(int i, bool& threadIsRunning, Hand hand) {
	OutWriter::getWriter()->writePhilosopherState(OutWriter::PhilosopherState::GET_FORKS, i);
	if (hand == Hand::RIGHT) {
		forks[right_fork(i)].wait(true, threadIsRunning, i, right_fork(i));
		forks[left_fork(i)].wait(true, threadIsRunning, i, left_fork(i));
	} else {
		forks[left_fork(i)].wait(true, threadIsRunning, i, left_fork(i));
		forks[right_fork(i)].wait(true, threadIsRunning, i, right_fork(i));
	}
}

void Philosopher::put_forks(int i, Hand hand) {
	OutWriter::getWriter()->writePhilosopherState(OutWriter::PhilosopherState::PUT_FORKS, i);
	if (hand == Hand::RIGHT) {
		forks[right_fork(i)].signal();
		forks[left_fork(i)].signal();
	} else {
		forks[left_fork(i)].signal();
		forks[right_fork(i)].signal();
	}
}

int Philosopher::right_fork(int i) {
	return i;
}

int Philosopher::left_fork(int i) {
	return (i + 1) % 5;
}
