#include "ExceptionError.h"
#include "Definitions.h"
#include "OutWriter.h"
#include "Philosopher.h"

#include <iostream>
#include <thread>
#include <chrono>
#include <vector>

bool RunData::dinner_ended = false;

void timer_thread() {
	auto start = std::chrono::system_clock::now();
	int duration_micros = 0;
	while (duration_micros < RunData::dinning_time) {
		auto stop = std::chrono::system_clock::now();
		auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop - start);
		duration_micros = duration.count();
	}
	RunData::dinner_ended = true;
}

void dinning(int index, Philosopher::Hand hand) {
	OutWriter::getWriter()->writePhilosopherState(OutWriter::PhilosopherState::START, index);
	std::this_thread::sleep_for(std::chrono::milliseconds(10));    //time to allow all philosophers to join before starting the dinner
	bool threadIsRunning = true;
	while (!RunData::dinner_ended) {
		Philosopher::think(index);
		Philosopher::get_forks(index, threadIsRunning, hand);
		if (!threadIsRunning) {
			OutWriter::getWriter()->writeThreadState(OutWriter::RUNNING, index);
			threadIsRunning = true;
		}
		Philosopher::eat(index);
		Philosopher::put_forks(index, hand);
	}
}

int main() {
	try {
		std::vector<std::thread> ThreadVector;
		// create threads
		for (int i = 0; i < RunData::philosophers_count - 1; ++i)
		{
			ThreadVector.emplace_back([i](){dinning(i, Philosopher::Hand::RIGHT);});
		}
		// add one left_handed philosopher thread
		ThreadVector.emplace_back([&]() {dinning(RunData::philosophers_count - 1, Philosopher::Hand::LEFT); });
		ThreadVector.emplace_back([&](){timer_thread();});
		//join threads
		for (auto& t : ThreadVector)
		{
			t.join();
		}
	}
	catch (ExceptionError& exception) {
		std::cout << exception.getError() << std::endl;
	}
	return 0;
}