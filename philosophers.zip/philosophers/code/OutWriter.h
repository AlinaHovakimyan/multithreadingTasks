#pragma once

#include <mutex>
#include <fstream>

class OutWriter {
public:
	enum State {
		RUNNING,
		WAITING
	};
	enum PhilosopherState {
		START,
		EAT,
		THINK,
		GET_FORKS,
		PUT_FORKS
	};
public:
	static OutWriter* getWriter();
	void writeThreadState(State state, int index, int fork_index = 0);
	void writePhilosopherState(PhilosopherState state, int index);
private:
	OutWriter();
	~OutWriter();
private:
	static OutWriter* m_outWriter;
	static std::mutex m_mutex;
	std::ofstream m_outputFile;
};
