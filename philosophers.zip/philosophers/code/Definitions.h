#pragma once

typedef int data_type;
namespace RunData {
	const int philosophers_count = 5;
	const int dinning_time = 10000;  // milliseconds
	extern bool dinner_ended;
}

