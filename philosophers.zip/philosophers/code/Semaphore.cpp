#include "Semaphore.h"
#include "OutWriter.h"

Semaphore::Semaphore(unsigned int count)
	: m_count(count)
{
}

Semaphore::Semaphore(const Semaphore& s2)
	: m_count(s2.m_count)
{
}

void Semaphore::signal()
{
	std::unique_lock<std::mutex> lock(m_mutex);
	++m_count;
	m_condition.notify_one();
}

void Semaphore::wait()
{
	std::unique_lock<std::mutex> lock(m_mutex);
	m_condition.wait(lock, [&]()->bool { return m_count > 0; });
	--m_count;
}

void Semaphore::wait(bool print, bool& isRunning, int index, int fork_index)
{
	std::unique_lock<std::mutex> lock(m_mutex);
	m_condition.wait(lock, [&]()->bool
		{
			if (!m_count && print) {
				isRunning = false;
				if (print) {
					OutWriter::getWriter()->writeThreadState(OutWriter::WAITING, index, fork_index);
				}
			};
			return m_count > 0;
		});
	--m_count;
}

template< typename R, typename P >
bool Semaphore::wait(const std::chrono::duration<R, P>& crRelTime)
{
	std::unique_lock<std::mutex> lock(m_mutex);
	if (!m_condition.wait_for(lock, crRelTime, [&]()->bool { return m_count > 0; }))
		return false;
	--m_count;
	return true;
}