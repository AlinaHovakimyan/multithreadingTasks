#pragma once
#include <vector>
#include "Semaphore.h"

namespace Philosopher {
	enum Hand {
		LEFT,
		RIGHT
	};
	const int think_duration = 1000;  // milliseconds
	const int eat_duration = 2000;    // milliseconds
	
	void get_forks(int i, bool& threadIsRunning, Hand hand);
	void put_forks(int i, Hand hand);
	void think(int index);
	void eat(int index);
	int right_fork(int i);
	int left_fork(int i);
};
