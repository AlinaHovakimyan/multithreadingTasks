#include "OutWriter.h"

#include "ExceptionError.h"
#include "Definitions.h"

OutWriter::OutWriter()
{
	m_outputFile.open("output.txt");
}

OutWriter::~OutWriter()
{
	m_outputFile.close();
}

OutWriter* OutWriter::getWriter()
{
	std::unique_lock<std::mutex> lock(m_mutex);
	if (!m_outWriter) {
		m_outWriter = new OutWriter();
	}
	return m_outWriter;
}

void OutWriter::writeThreadState(State state, int index, int fork_index)
{
	std::unique_lock<std::mutex> lock(m_mutex);
	switch (state) {
	case RUNNING:
		m_outputFile << "Philosopher " << index << " thread's state changed to RUNNING" << std::endl;
		break;
	case WAITING:
		m_outputFile << "Philosospher " << index << " is waiting for fork " << fork_index << std::endl;
		break;
	default:
		throw ExceptionError("unknown state");
	}
}

void OutWriter::writePhilosopherState(PhilosopherState state, int index)
{
	std::unique_lock<std::mutex> lock(m_mutex);
	m_outputFile << "Philosopher " << index << " is ";
	switch (state) {
	case START:
		m_outputFile << "joining to the dining table" << std::endl;
		break;
	case EAT:
		m_outputFile << "eating" << std::endl;
		break;
	case THINK:
		m_outputFile << "thinking" << std::endl;
		break;
	case GET_FORKS:
		m_outputFile << "getting forks" << std::endl;
		break;
	case PUT_FORKS:
		m_outputFile << "putting forks on the table" << std::endl;
		break;
	default:
		throw ExceptionError("unknown state");
	}
}

std::mutex OutWriter::m_mutex;
OutWriter* OutWriter::m_outWriter;